import { useEffect, useMemo, useState, useCallback } from 'react'
import { usePushSubscription } from '@/hooks/usePushSubscription'
import Image from 'next/image'
import { useTranslation } from 'react-i18next'
import { useRouter } from 'next/router'
import { getTranslation } from '@/lib/translations'
import { supabase } from '@/lib/supabase'
import { tAddDream } from '@/lib/addDreamTranslations'
import { ARCHETYPE_LOCALIZATIONS } from '@/lib/archetypeTranslations'
import { getDreamCardText } from '@/lib/dreamCardTranslations'
import DreamAnalysisView from '@/components/DreamAnalysisView'
import DeepAnalysisConfirmationModal from '@/components/DeepAnalysisConfirmationModal'
import DeepAnalysisCarouselModal from '@/components/DeepAnalysisCarouselModal'
import StoryModeModal from '@/components/StoryModeModal'

const GUMROAD_PRODUCT_URL = 'https://shop.lunosfer.com'

export default function DreamCard({ dream, lang, onTranslate, translating, translated, translatedContent, translatedAnalysis, currentUserId }) {
  const { i18n } = useTranslation()
  const router = useRouter()
  const [mounted, setMounted] = useState(false)
  useEffect(() => { setMounted(true) }, [])

  const currentLang = useMemo(() => {
    const rawLang = lang || (mounted ? (i18n?.language || 'en') : 'en')
    return String(rawLang).toLowerCase().split('-')[0]
  }, [lang, i18n, mounted])

  const t = getDreamCardText(currentLang)

  const [user, setUser] = useState(null)
  const [liked, setLiked] = useState(false)
  const [likesCount, setLikesCount] = useState(dream.likes_count || 0)
  const [showComments, setShowComments] = useState(false)
  const [comments, setComments] = useState([])
  const [newComment, setNewComment] = useState('')
  const [commentsCount, setCommentsCount] = useState(dream.comments_count || 0)
  const [commentsLoading, setCommentsLoading] = useState(false)
  
  const [showAnalysisModal, setShowAnalysisModal] = useState(false)
  const [showConfirmModal, setShowConfirmModal] = useState(false)
  const [showStoryMode, setShowStoryMode] = useState(false)

  const { subscribe: subscribeToPush } = usePushSubscription()
  const [premiumAuras, setPremiumAuras] = useState(0)
  const [premiumGenerating, setPremiumGenerating] = useState(false)
  const [premiumQueued, setPremiumQueued] = useState(false)
  const [generatingImage, setGeneratingImage] = useState(false)
  const [premiumError, setPremiumError] = useState('')
  const [premiumAnalysis, setPremiumAnalysis] = useState(dream?.premium_deep_analysis || null)
  const [analysisOverride, setAnalysisOverride] = useState(null)
  const [toastMessage, setToastMessage] = useState('')
  const [showToast, setShowToast] = useState(false)

  const effectiveDream = useMemo(() => (analysisOverride ? { ...dream, ...analysisOverride } : dream), [dream, analysisOverride])
  const isAnalysisPreparing = useMemo(() => {
    if (premiumAnalysis || effectiveDream?.premium_deep_analysis) return false
    if (premiumQueued) return true
    return effectiveDream?.premium_deep_analysis_status === 'pending' || effectiveDream?.premium_deep_analysis_status === 'processing'
  }, [premiumAnalysis, effectiveDream, premiumQueued])
  // Kuyrukta/işlemdeyken birkaç saniyede bir arka planda bitip bitmediğini
  // kontrol et — aksi halde analiz tamamlansa bile kullanıcı sayfayı elle
  // yenilemeden ne bildirim dışında bir değişiklik ne de "göster" butonunu görür.
  useEffect(() => {
    if (!isAnalysisPreparing) return

    let active = true
    const dreamId = dream.id

    const poll = async () => {
      try {
        const res = await fetch(`/api/get-dream?id=${dreamId}`)
        if (!active || !res.ok) return
        const { dream: fresh } = await res.json()
        if (!active || !fresh) return

        if (fresh.premium_deep_analysis_status === 'generated' && fresh.premium_deep_analysis) {
          setPremiumAnalysis(fresh.premium_deep_analysis)
          setAnalysisOverride((prev) => ({ ...prev, ...fresh }))
          setPremiumQueued(false)
        } else if (fresh.premium_deep_analysis_status === 'failed') {
          setPremiumError(fresh.premium_deep_analysis_error || t.analysisTimeout || 'Analysis failed')
          setPremiumQueued(false)
        }
      } catch {
        // sessizce geç, bir sonraki taramada tekrar denenecek
      }
    }

    const intervalId = setInterval(poll, 6000)
    poll()

    return () => {
      active = false
      clearInterval(intervalId)
    }
  }, [isAnalysisPreparing, dream.id])

  const isOwner = useMemo(() => {
    // Ebeveyn sayfa zaten oturumu çözmüşse (currentUserId) buna güven —
    // bu, her kartın kendi başına asenkron auth sorgusu bitene kadar
    // "sahip değilmiş gibi" görünmesinden (ve bu yüzden yanlışlıkla
    // "arkadaşına hediye" metni göstermesinden) kaynaklanan yarış durumunu ortadan kaldırır.
    const effectiveUserId = currentUserId ?? user?.id
    if (!effectiveUserId) return false
    const ownerId = effectiveDream?.user_id ?? effectiveDream?.owner_id ?? effectiveDream?.author_id ?? effectiveDream?.uid
    if (ownerId == null && process.env.NODE_ENV !== 'production') {
      console.warn('[DreamCard] Could not find an owner id field on the dream object (checked user_id, owner_id, author_id, uid). isOwner will default to false.', effectiveDream)
    }
    return ownerId != null && String(ownerId) === String(effectiveUserId)
  }, [user, effectiveDream, currentUserId])

  useEffect(() => {
    let active = true

    const applyUser = async (currentUser) => {
      if (!active) return
      setUser(currentUser)
      if (currentUser) {
        const { data: profile } = await supabase
          .from('user_profiles')
          .select('premium_analysis_auras')
          .eq('id', currentUser.id)
          .single()
        if (active && profile) setPremiumAuras(profile.premium_analysis_auras || 0)
      }
    }

    // getSession() reads from local storage synchronously and avoids the
    // hydration race condition that getUser() (a network round-trip) has
    // on first render, right after the page loads.
    supabase.auth.getSession().then(({ data: { session } }) => {
      applyUser(session?.user || null)
    })

    const { data: authListener } = supabase.auth.onAuthStateChange((_event, session) => {
      applyUser(session?.user || null)
    })

    return () => {
      active = false
      authListener?.subscription?.unsubscribe()
    }
  }, [])

  const triggerToast = (msg) => { setToastMessage(msg); setShowToast(true); setTimeout(() => setShowToast(false), 2800) }

  const translateArchetype = useCallback((arch) => {
    const cleanArch = String(arch).trim()
    return ARCHETYPE_LOCALIZATIONS[currentLang]?.[cleanArch] || cleanArch
  }, [currentLang])

  const translateEmotion = useCallback((sentiment) => {
    const emotionKey = `emotion.${String(sentiment).toLowerCase()}`
    const localized = tAddDream(emotionKey, currentLang)
    return localized && localized !== emotionKey ? localized : sentiment
  }, [currentLang])

  const handleGenerateImageOnly = async () => {
    setPremiumError('')
    setGeneratingImage(true)
    try {
      const { data: { session } } = await supabase.auth.getSession()
      if (!session) throw new Error(t.loginRequired || 'Please log in to continue')
      const res = await fetch('/api/generate-dream-image', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${session.access_token}` },
        body: JSON.stringify({ dreamId: dream.id }),
      })
      const data = await res.json()
      if (!res.ok) throw new Error(data.details || data.error || 'Failed to generate')
      setAnalysisOverride({ ...effectiveDream, ai_image_url: data.imageUrl })
      setPremiumAuras(data.aurasLeft)
      triggerToast(isOwner ? t.imageSuccess : t.imageGiftSuccess)
    } catch (err) {
      setPremiumError(err.message)
    } finally {
      setGeneratingImage(false)
    }
  }

  const handlePremiumAnalysisExecute = async () => {
    if (premiumGenerating) return
    setPremiumError('')
    setPremiumGenerating(true)
    try {
      const { data: { session } } = await supabase.auth.getSession()
      if (!session) throw new Error(t.loginRequired || 'Please log in to continue')

      // Bildirim izni bu an bağlamda anlamlı olduğu için burada isteniyor
      // (sonucu bildirimle alacaklarını söylediğimiz an). Reddedilirse veya
      // desteklenmiyorsa sessizce devam eder — kuyruk/uygulama-içi bildirim
      // her durumda çalışır.
      subscribeToPush()

      const res = await fetch('/api/generate-deep-analysis', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${session.access_token}` },
        body: JSON.stringify({ dreamId: dream.id, lang: currentLang }),
      })
      let data
      try {
        data = await res.json()
      } catch {
        throw new Error(t.analysisTimeout || 'The analysis is taking longer than expected. Please try again in a moment.')
      }
      if (!res.ok) {
        const failureDetail = Array.isArray(data.failures) && data.failures.length
          ? ' | ' + data.failures.map(f => {
              const issues = Array.isArray(f.issues) && f.issues.length ? ` [${f.issues.join(', ')}]` : ''
              return `${f.provider}: ${f.reason}${issues}`
            }).join(', ')
          : ''
        throw new Error(`${data.error || 'Failed'}${data.details ? ` (${data.details})` : ''}${failureDetail}`)
      }

      setPremiumAuras(data.aurasLeft)
      setShowConfirmModal(false)

      if (data.generated && data.analysis) {
        // PLAN A: analiz zaten bu yanıtla birlikte geldi — kuyruğa hiç girmedi.
        setPremiumAnalysis(data.analysis)
        setAnalysisOverride((prev) => ({ ...prev, premium_deep_analysis: data.analysis, premium_deep_analysis_status: 'generated' }))
        setShowAnalysisModal(true)
      } else {
        // PLAN B: kuyruğa alındı, arka planda işlenecek.
        setPremiumQueued(true)
        triggerToast(t.analysisQueuedToast)
      }
    } catch (err) {
      setPremiumError(err.message)
      setShowConfirmModal(false)
    } finally {
      setPremiumGenerating(false)
    }
  }

  return (
    <>
      <article className="glass-card p-6 rounded-3xl border border-white/10 bg-slate-900/40">
        {effectiveDream.ai_image_url && (
          <div className="relative w-full aspect-square rounded-2xl overflow-hidden mb-4">
            <Image
              src={effectiveDream.ai_image_url}
              alt=""
              fill
              sizes="(max-width: 640px) 100vw, 600px"
              className="object-cover"
            />
          </div>
        )}
        <p className="mb-6">{translated ? translatedContent : dream.content}</p>

        {(() => {
          const summary = effectiveDream?.[`ai_summary_${currentLang}`] || effectiveDream?.ai_summary || effectiveDream?.ai_summary_en
          const motiv = effectiveDream?.[`ai_motiv_${currentLang}`] || effectiveDream?.ai_motiv || effectiveDream?.ai_motiv_en
          if (!summary && !motiv) return null
          return (
            <div className="mb-5 rounded-2xl border border-fuchsia-300/15 bg-fuchsia-500/8 p-4">
              <div className="mb-2 flex items-center gap-2">
                <span className="text-fuchsia-200">🜂</span>
                <p className="text-xs uppercase tracking-[0.18em] text-fuchsia-100">
                  {t.jungianAnalysisLabel}
                </p>
              </div>
              {summary && <p className="text-sm leading-7 text-slate-200">{summary}</p>}
              {motiv && (
                <p className="mt-3 border-l border-fuchsia-300/30 pl-3 text-xs italic text-slate-400">
                  "{motiv}"
                </p>
              )}
            </div>
          )
        })()}
        
        <button
          onClick={() => {
            if (isAnalysisPreparing) return
            premiumAnalysis ? setShowAnalysisModal(true) : setShowConfirmModal(true)
          }}
          disabled={isAnalysisPreparing}
          className="w-full bg-fuchsia-600 p-4 rounded-xl text-white font-bold mb-3 disabled:opacity-60 disabled:cursor-not-allowed"
        >
          {premiumAnalysis
            ? t.exploreCards
            : isAnalysisPreparing
              ? t.analysisPreparing
              : (isOwner ? t.getDeepAnalysis : t.giftDeepAnalysis)}
        </button>

        {!premiumAnalysis && !effectiveDream.ai_image_url && (
            <button onClick={handleGenerateImageOnly} disabled={generatingImage} className="w-full bg-cyan-600 p-4 rounded-xl text-white font-bold mb-3 hover:bg-cyan-500 transition">
                {generatingImage ? t.generatingImage : (isOwner ? t.generateImage : t.giftDreamImage)}
            </button>
        )}
        {premiumError && <p className="text-red-500 text-xs mb-4">{premiumError}</p>}
      </article>

      {showConfirmModal && <DeepAnalysisConfirmationModal isOpen={showConfirmModal} onClose={() => setShowConfirmModal(false)} auras={premiumAuras} onConfirm={handlePremiumAnalysisExecute} lang={currentLang} gumroadUrl={GUMROAD_PRODUCT_URL} isGift={!isOwner} isGenerating={premiumGenerating} />}
      {showAnalysisModal && (
        <div className="fixed inset-0 z-[100] flex items-center justify-center p-4 bg-black/90 backdrop-blur-md" onClick={() => setShowAnalysisModal(false)}>
           <DeepAnalysisCarouselModal isOpen={showAnalysisModal} onClose={() => setShowAnalysisModal(false)} premiumAnalysis={premiumAnalysis || effectiveDream?.premium_deep_analysis} lang={currentLang} dreamTitle={dream.ai_title} dreamContent={translated ? translatedContent : dream.content} dreamImage={effectiveDream.ai_image_url} dreamId={dream.id} onGenerateImageOnly={handleGenerateImageOnly} generatingImage={generatingImage} premiumError={premiumError} translateArchetype={translateArchetype} onOpenStoryMode={() => setShowStoryMode(true)} />
        </div>
      )}
      {showStoryMode && (
        <StoryModeModal
          isOpen={showStoryMode}
          onClose={() => setShowStoryMode(false)}
          dream={effectiveDream}
          premiumAnalysis={premiumAnalysis || effectiveDream?.premium_deep_analysis}
          lang={currentLang}
        />
      )}
    </>
  )
}